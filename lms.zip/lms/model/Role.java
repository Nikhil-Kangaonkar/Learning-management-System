package com.eskill.lms.model;

public enum Role {
    STUDENT,
    ADMIN
}
